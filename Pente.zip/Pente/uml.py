pip install pylint
Pyreverse -o png game.py
