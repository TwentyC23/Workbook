Pour avoir les polices veuillez les télécharger dans le fichier fonts de Pente.

CREDITS

Pente (a board game) by Loïc Leguille
Buttons- art from Kenney.nl
Japanese Robot- font from Darrell Flood
Korean Calligraphy- font from hijoju
Peace at last- Music by Jan125